"""
-------------------------------------------------------
Name: motor
Creator:  Peter Y K Cheung, Imperial College London
Created:  3 March 2017
Revision: 1.1
Revision: 2.0  21 Jan 2022
-------------------------------------------------------
This is driver class controls the motors via the PyBench board.
Rev 1.1 only measure speed by counting interrupt on one of two hall sensors
Rev 2.0 Interrupt generated on BOTH sensors and read the other sensor value
        CW rotation: sensorA interrupt + sensorB=0 followed by
           ....      sensorB interrupt + sensorA=1  state = 01
       CCW rotation: sensorB interrupt + sensorA=1 followed by
           ....      sensorB interrupt + sensorA=0  state = 10    
Remember that the two motors are mounted with opposition rotation
Also sensor readings very noisy. Therefore monitor 3 consecutive states
        CW gives reading of 010101
       CCW gives reading of 101010
All other states are regarded as invalid      
-------------------------------------------------------
The MIT License (MIT)
Copyright (c) 2022 Peter Cheung
"""

import pyb
import micropython
from pyb import Pin, Timer

micropython.alloc_emergency_exception_buf(100)

class DRIVE(object):
    MEASUREMENT_PERIOD = 0.1
    SPEED_SCALE = 7 / MEASUREMENT_PERIOD  # in mm/sec

    def __init__(self):

        # set up motor with PWM and timer control
        self.A1 = Pin("X3", Pin.OUT_PP)  # A is right motor
        self.A2 = Pin("X4", Pin.OUT_PP)
        self.B1 = Pin("X7", Pin.OUT_PP)  # B is left motor
        self.B2 = Pin("X8", Pin.OUT_PP)
        self.PWMA = Pin("X1")
        self.PWMB = Pin("X2")
        self.speed = 0  # +100 full speed forward, -100 full speed back
        self.turn = 0  # turn is +/-100; 0 = left/right same speed,
        # ... +50 = left at speed, right stop, +100 = right back full
        # Configure counter 2 to produce 1kHz clock signal
        self.tim = Timer(2, freq=1000)
        # Configure timer to provide PWM signal
        self.motorA = self.tim.channel(1, Timer.PWM, pin=self.PWMA)
        self.motorB = self.tim.channel(2, Timer.PWM, pin=self.PWMB)
        self.lsf = 0  # left motor speed factor +/- 1
        self.rsf = 0  # right motor speed factor +/- 1
        self.countA = 0  # speed pulse count for motorA
        self.countB = 0  # speed pulse count for motorB
        self.speedA = 0  # actual speed of motorA
        self.speedB = 0  # actual speed of motorB
        self.stateA = 0  # state is 01 for CW and 10 for CC
        self.stateB = 0
        self.dirA = 0    # Show 3 consecutive states 010101 = 21, or 101010 = 42
        self.dirB = 0    # anything else is not legal

        # Create external interrupts for motorA and motorB Hall Effect Senors
        self.motorA_int1 = pyb.ExtInt(
            "Y4", pyb.ExtInt.IRQ_RISING, pyb.Pin.PULL_NONE, self.isr_motorA1
        )
        self.motorA_int2 = pyb.ExtInt(
            "Y5", pyb.ExtInt.IRQ_RISING, pyb.Pin.PULL_NONE, self.isr_motorA2
        )
        self.motorB_int1 = pyb.ExtInt(
            "Y6", pyb.ExtInt.IRQ_RISING, pyb.Pin.PULL_NONE, self.isr_motorB1
        )
        self.motorB_int2 = pyb.ExtInt(
            "Y7", pyb.ExtInt.IRQ_RISING, pyb.Pin.PULL_NONE, self.isr_motorB2
        )       
        self.speed_timer = pyb.Timer(8, freq=10)
        self.speed_timer.callback(self.isr_speed_timer)
        self.sensorA1 = pyb.Pin("Y5", Pin.IN)
        self.sensorA2 = pyb.Pin("Y4", Pin.IN)
        self.sensorB1 = pyb.Pin("Y7", Pin.IN)
        self.sensorB2 = pyb.Pin("Y6", Pin.IN)

    def isr_motorA1(self, line):
        self.countA += 1
        self.stateA = self.sensorA1.value() << 1

    def isr_motorA2(self, line):
        self.countA += 1
        # shift dirA left 2 bits, and add current state, then mask to retain lower bits
        # ... for 3 consecutive states.  63 is mask for lower 6 bits
        self.dirA = (self.sensorA2.value() | self.stateA | (self.dirA << 2)) & 63

    def isr_motorB1(self, line):
        self.countB += 1
        self.stateB = self.sensorB1.value() << 1

    def isr_motorB2(self, line):
        self.countB += 1
        self.dirB = (self.sensorB2.value() | self.stateB | (self.dirB << 2)) & 63

    def isr_speed_timer(self, t):
        self.speedA = self.countA
        self.speedB = self.countB
        self.countA = 0
        self.countB = 0
        pyb.LED(3).toggle()

    def set_speed(self, value):
        self.speed = value

    def get_speedA(self):
        return self.speedA

    def get_speedB(self):
        return self.speedB

# Direction returned as 1 = CW, -1 = CCW, 0 = invalid direction reading
    def get_dirA(self):
        if self.dirA == 21:
            return 1
        elif self.dirA == 42:
            return -1
        else:
            return 0

    def get_dirB(self):
        if self.dirB == 42:
            return 1
        elif self.dirB == 21:
            return -1
        else:
            return 0

    def set_turn(self, value):
        self.turn = value

    def get_turn(self):
        return self.turn

    def right_forward(self, value):
        self.A2.high()
        self.A1.low()
        self.motorA.pulse_width_percent(abs(value))

    def right_back(self, value):
        self.A2.low()
        self.A1.high()
        self.motorA.pulse_width_percent(abs(value))

    def left_forward(self, value):
        self.B1.high()
        self.B2.low()
        self.motorB.pulse_width_percent(abs(value))

    def left_back(self, value):
        self.B1.low()
        self.B2.high()
        self.motorB.pulse_width_percent(abs(value))

    def stop(self):
        # Motor in idle state
        self.speed = 0
        self.A1.low()
        self.A2.low()
        self.B1.low()
        self.B2.low()
        self.motorA.pulse_width_percent(0)
        self.motorB.pulse_width_percent(0)

    def drive(self):
        DEADZONE = 5
        if (self.speed >= DEADZONE) and (self.turn == 0):  # straight forward
            self.right_forward(self.speed)
            self.left_forward(self.speed)
        elif (self.speed <= -DEADZONE) and (self.turn == 0):  # straight backward
            self.right_back(self.speed)
            self.left_back(self.speed)
        elif (self.speed >= DEADZONE) and (self.turn > 0):  # forward right
            self.lsf = 1  # left wheel speed factor is 1
            self.rsf = 1 - self.turn / 50
            self.left_forward(self.speed)

            if self.rsf > 0:
                self.right_forward(self.rsf * self.speed)
            else:
                self.right_back(self.rsf * self.speed)
        elif (self.speed >= DEADZONE) and (self.turn < 0):  # forward left
            self.rsf = 1  # right wheel speed factor is 1
            self.lsf = 1 + self.turn / 50
            self.right_forward(self.rsf * self.speed)
            if self.lsf > 0:
                self.left_forward(self.lsf * self.speed)
            else:
                self.left_back(self.lsf * self.speed)
        elif (self.speed <= DEADZONE) and (self.turn > 0):  # backward right
            self.rsf = 1  # right wheel speed factor is 1
            self.lsf = 1 - self.turn / 50
            self.right_back(self.speed)
            if self.lsf > 0:
                self.left_back(self.lsf * self.speed)
            else:
                self.left_forward(self.lsf * self.speed)
        elif (self.speed <= DEADZONE) and (self.turn < 0):  # backward left
            self.lsf = 1  # left wheel speed factor is 1
            self.rsf = 1 + self.turn / 50
            self.left_back(self.speed)
            if self.lsf < 0:
                self.right_back(self.rsf * self.speed)
            else:
                self.right_forward(self.rsf * self.speed)
        else:
            self.stop()