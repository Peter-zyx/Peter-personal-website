import pyb
from pyb import Pin, Timer, ExtInt
from oled_938 import OLED_938
import micropython
import math

micropython.alloc_emergency_exception_buf(100)

# =========================================================
# Motor pins
# =========================================================
A1 = Pin('X3', Pin.OUT_PP)
A2 = Pin('X4', Pin.OUT_PP)
PWMA = Pin('X1')

B1 = Pin('X7', Pin.OUT_PP)
B2 = Pin('X8', Pin.OUT_PP)
PWMB = Pin('X2')

# PWM timer
tim = Timer(2, freq=1000)
motorA = tim.channel(1, Timer.PWM, pin=PWMA)
motorB = tim.channel(2, Timer.PWM, pin=PWMB)

# =========================================================
# Motor functions
# =========================================================
def A_forward(value):
    value = max(0, min(100, int(value)))
    A1.low()
    A2.high()
    motorA.pulse_width_percent(value)

def A_back(value):
    value = max(0, min(100, int(value)))
    A2.low()
    A1.high()
    motorA.pulse_width_percent(value)

def A_stop():
    A1.high()
    A2.high()
    motorA.pulse_width_percent(0)

def B_forward(value):
    value = max(0, min(100, int(value)))
    B2.low()
    B1.high()
    motorB.pulse_width_percent(value)

def B_back(value):
    value = max(0, min(100, int(value)))
    B1.low()
    B2.high()
    motorB.pulse_width_percent(value)

def B_stop():
    B1.high()
    B2.high()
    motorB.pulse_width_percent(0)

def drive_signed_A(cmd):
    if abs(cmd) < 2:
        A_stop()
    elif cmd > 0:
        A_forward(cmd)
    else:
        A_back(-cmd)

def drive_signed_B(cmd):
    if abs(cmd) < 2:
        B_stop()
    elif cmd > 0:
        B_forward(cmd)
    else:
        B_back(-cmd)

def stop_all():
    A_stop()
    B_stop()

# =========================================================
# OLED setup
# =========================================================
i2c_oled = pyb.I2C(2, pyb.I2C.MASTER)
oled_addr = i2c_oled.scan()[0]

oled = OLED_938(
    pinout={"sda": "Y10", "scl": "Y9", "res": "Y8"},
    height=64,
    external_vcc=False,
    i2c_devid=oled_addr,
)

oled.poweron()
oled.init_display()

def oled_clear():
    try:
        oled.clear()
    except:
        try:
            oled.fill(0)
        except:
            pass

def oled_show_idle():
    oled_clear()
    oled.draw_text(0, 0, 'Challenge 2')
    oled.draw_text(0, 20, 'Tilt Motor Task')
    oled.draw_text(0, 40, 'Press USER to start')
    oled.display()

def oled_show_running():
    oled_clear()
    oled.draw_text(0, 0, 'Running...')
    oled.display()

def oled_show_error(msg):
    oled_clear()
    oled.draw_text(0, 0, 'Runtime error')
    oled.draw_text(0, 16, str(msg))
    oled.display()

# =========================================================
# USER switch
# =========================================================
switch = pyb.Switch()

# =========================================================
# Speed sensing
# =========================================================
A_count = 0
B_count = 0
A_speed = 0
B_speed = 0

def isr_motorA(dummy):
    global A_count
    A_count += 1

def isr_motorB(dummy):
    global B_count
    B_count += 1

def isr_speed_timer(dummy):
    global A_count, B_count, A_speed, B_speed
    A_speed = A_count
    B_speed = B_count
    A_count = 0
    B_count = 0

motorA_int = ExtInt('Y4', ExtInt.IRQ_RISING, Pin.PULL_NONE, isr_motorA)
motorB_int = ExtInt('Y6', ExtInt.IRQ_RISING, Pin.PULL_NONE, isr_motorB)

speed_timer = pyb.Timer(4, freq=10)   # every 0.1 s
speed_timer.callback(isr_speed_timer)

# =========================================================
# IMU (MPU6050) setup
# =========================================================
i2c_imu = pyb.I2C(1, pyb.I2C.MASTER, baudrate=400000)

IMU_ADDR = 0x68
PWR_MGMT_1   = 0x6B
ACCEL_XOUT_H = 0x3B
GYRO_XOUT_H  = 0x43

def i2c_write_reg(addr, reg, val):
    i2c_imu.mem_write(val, addr, reg)

def i2c_read_regs(addr, reg, nbytes):
    return i2c_imu.mem_read(nbytes, addr, reg)

def to_int16(msb, lsb):
    v = (msb << 8) | lsb
    if v & 0x8000:
        v -= 65536
    return v

# wake up IMU
i2c_write_reg(IMU_ADDR, PWR_MGMT_1, 0x00)
pyb.delay(100)

def read_accel_gyro():
    acc = i2c_read_regs(IMU_ADDR, ACCEL_XOUT_H, 6)
    gyr = i2c_read_regs(IMU_ADDR, GYRO_XOUT_H, 6)

    ax = to_int16(acc[0], acc[1])
    ay = to_int16(acc[2], acc[3])
    az = to_int16(acc[4], acc[5])

    gx = to_int16(gyr[0], gyr[1])
    gy = to_int16(gyr[2], gyr[3])
    gz = to_int16(gyr[4], gyr[5])

    return ax, ay, az, gx, gy, gz

# =========================================================
# Angle estimation using complementary filter
# =========================================================
# MPU6050 default gyro sensitivity = 131 LSB/(deg/s)
GYRO_SCALE = 131.0
ALPHA = 0.96

pitch = 0.0
roll = 0.0

def update_pitch_roll(dt, pitch, roll):
    ax, ay, az, gx, gy, gz = read_accel_gyro()

    # accel angles
    pitch_acc = math.degrees(math.atan2(-ax, math.sqrt(ay * ay + az * az)))
    roll_acc  = math.degrees(math.atan2(ay, az))

    # gyro rates (deg/s)
    gx_dps = gx / GYRO_SCALE
    gy_dps = gy / GYRO_SCALE

    # complementary filter
    # axis sign may need changing depending on board mounting
    pitch = ALPHA * (pitch + gy_dps * dt) + (1 - ALPHA) * pitch_acc
    roll  = ALPHA * (roll  + gx_dps * dt) + (1 - ALPHA) * roll_acc

    return pitch, roll

# =========================================================
# Mapping angle to motor command
# =========================================================
def angle_to_cmd(angle_deg, max_angle=30.0, deadband=3.0):
    if -deadband < angle_deg < deadband:
        return 0

    if angle_deg > max_angle:
        angle_deg = max_angle
    elif angle_deg < -max_angle:
        angle_deg = -max_angle

    return int(100.0 * angle_deg / max_angle)

# =========================================================
# Start in idle mode
# =========================================================
oled_show_idle()
print('Idle mode: press USER to start')

while not switch():
    pyb.delay(20)

while switch():
    pyb.delay(20)

oled_show_running()
print('Program started')

# =========================================================
# Main loop
# =========================================================
last_ms = pyb.millis()
last_oled_ms = pyb.millis()
last_print_ms = pyb.millis()

try:
    while True:
        now = pyb.millis()
        dt = pyb.elapsed_millis(last_ms) / 1000.0
        last_ms = now

        # keep dt sane
        if dt <= 0:
            dt = 0.01
        elif dt > 0.1:
            dt = 0.1

        # update angles
        pitch, roll = update_pitch_roll(dt, pitch, roll)

        # map to motor commands
        cmdA = angle_to_cmd(pitch)   # Motor A by pitch
        cmdB = angle_to_cmd(roll)    # Motor B by roll

        # if physical direction is reversed during testing,
        # change sign here:
        # cmdA = angle_to_cmd(-pitch)
        # cmdB = angle_to_cmd(-roll)

        drive_signed_A(cmdA)
        drive_signed_B(cmdB)

        # rps calculation
        # A_speed and B_speed are pulse counts in 0.1 s
        rpsA = (A_speed * 10) / 39.0
        rpsB = (B_speed * 10) / 39.0

        # OLED refresh at lower rate only
        if pyb.elapsed_millis(last_oled_ms) >= 200:
            last_oled_ms = pyb.millis()
            oled_clear()
            oled.draw_text(0, 0,  'Tilt -> Motors')
            oled.draw_text(0, 12, 'Pitch:{:6.1f}'.format(pitch))
            oled.draw_text(0, 22, 'Roll :{:6.1f}'.format(roll))
            oled.draw_text(0, 34, 'A:{:4d}% {:5.2f}rps'.format(cmdA, rpsA))
            oled.draw_text(0, 44, 'B:{:4d}% {:5.2f}rps'.format(cmdB, rpsB))
            oled.display()

        # serial debug print at lower rate
        if pyb.elapsed_millis(last_print_ms) >= 500:
            last_print_ms = pyb.millis()
            print('pitch={:.1f}, roll={:.1f}, A={:d}, B={:d}, rpsA={:.2f}, rpsB={:.2f}'.format(
                pitch, roll, cmdA, cmdB, rpsA, rpsB
            ))

        pyb.delay(10)

except Exception as e:
    print('Error:', e)
    oled_show_error(e)

finally:
    stop_all()
    print('Motors stopped')
    