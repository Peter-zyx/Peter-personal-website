import pyb
from pyb import Pin, Timer, ADC
from audio import MICROPHONE
from neopixel import NeoPixel
from oled_938 import OLED_938
from array import array
import micropython

micropython.alloc_emergency_exception_buf(100)

# OLED setup (outside main loop)
i2c = pyb.I2C(2, pyb.I2C.MASTER)
scan = i2c.scan()
oled_addr = scan[0] if scan else 0x3C

oled = OLED_938(
    pinout={"sda": "Y10", "scl": "Y9", "res": "Y8"},
    height=64,
    external_vcc=False,
    i2c_devid=oled_addr,
)

oled.poweron()
oled.init_display()
oled.draw_text(0, 0, "Challenge 1")
oled.draw_text(0, 20, "Dancing LEDs")
oled.draw_text(0, 40, "Ready")
oled.display()

# wait for user button
switch = pyb.Switch()
while not switch():
    pyb.delay(1)
while switch():
    pass

oled.draw_text(0, 40, "Running")
oled.display()

# neopixel setup
NUM_LEDS = 8
np = NeoPixel(Pin("Y12", Pin.OUT), NUM_LEDS)

def clear_leds():
    for i in range(NUM_LEDS):
        np[i] = (0, 0, 0)
    np.write()

def show_leds(n):
    for i in range(NUM_LEDS):
        if i < n:
            np[i] = (0, 0, 50)
        else:
            np[i] = (0, 0, 0)
    np.write()

clear_leds()

# microphone setup
sample_timer = pyb.Timer(7, freq=8000)
mic = ADC(Pin('Y11'))
N = 160
audio = MICROPHONE(sample_timer, mic, N)

# beat detection setup
M = 50
energy_buf = array('L', [0] * M)
ptr = 0
sum_energy = 0

BEAT_THRESHOLD = 1.6
MIN_BEAT_PERIOD = 300
last_beat = pyb.millis()

while True:
    if audio.buffer_is_filled():
        E = audio.inst_energy()
        audio.reset_buffer()

        sum_energy = sum_energy - energy_buf[ptr] + E
        energy_buf[ptr] = E
        ptr = (ptr + 1) % M
        avg_energy = sum_energy / M

        if avg_energy > 0:
            c = E / avg_energy
        else:
            c = 0

        now = pyb.millis()

        if c > BEAT_THRESHOLD and (now - last_beat) > MIN_BEAT_PERIOD:
            last_beat = now

            if c > 2.5:
                level = 8
            elif c > 2.1:
                level = 5
            elif c > 1.7:
                level = 3
            else:
                level = 1

            show_leds(level)
            pyb.delay(100)
            clear_leds()