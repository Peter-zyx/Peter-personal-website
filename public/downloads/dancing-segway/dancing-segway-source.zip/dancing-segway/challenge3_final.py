import pyb
import micropython
from pyb import Pin, Timer
from oled_938 import OLED_938
from mpu6050 import MPU6050

# -----------------------------
# Motor pins
# -----------------------------
A1 = Pin('X3', Pin.OUT_PP)
A2 = Pin('X4', Pin.OUT_PP)
PWMA = Pin('X1')

B1 = Pin('X7', Pin.OUT_PP)
B2 = Pin('X8', Pin.OUT_PP)
PWMB = Pin('X2')

# -----------------------------
# PWM setup
# -----------------------------
tim = Timer(2, freq=1000)
motorA = tim.channel(1, Timer.PWM, pin=PWMA)
motorB = tim.channel(2, Timer.PWM, pin=PWMB)

# -----------------------------
# OLED
# -----------------------------
i2c = pyb.I2C(2, pyb.I2C.MASTER)
oled = OLED_938(
    pinout={"sda":"Y10","scl":"Y9","res":"Y8"},
    height=64,
    external_vcc=False,
    i2c_devid=i2c.scan()[0],
)
oled.poweron()
oled.init_display()

def oled_show_idle():
    oled.clear()
    oled.draw_text(0, 0, "Challenge 3")
    oled.draw_text(0, 20, "Self-balancing Motor")
    oled.draw_text(0, 40, "Press USER")
    oled.display()

def oled_show_running():
    oled.clear()
    oled.draw_text(0, 0, "Running")
    oled.display()

# -----------------------------
# USER switch
# -----------------------------
switch = pyb.Switch()

# -----------------------------
# IMU
# -----------------------------
imu = MPU6050(1, False)

# -----------------------------
# Motor control
# -----------------------------
def A_forward(v):
    A1.low()
    A2.high()
    motorA.pulse_width_percent(int(v))

def A_back(v):
    A2.low()
    A1.high()
    motorA.pulse_width_percent(int(v))

def A_stop():
    A1.high()
    A2.high()
    motorA.pulse_width_percent(0)

def B_forward(v):
    B2.low()
    B1.high()
    motorB.pulse_width_percent(int(v))

def B_back(v):
    B1.low()
    B2.high()
    motorB.pulse_width_percent(int(v))

def B_stop():
    B1.high()
    B2.high()
    motorB.pulse_width_percent(0)

# -----------------------------
# Hall sensors
# -----------------------------
A_count = 0
B_count = 0
A_speed_count = 0
B_speed_count = 0

def isr_motorA(dummy):
    global A_count
    A_count += 1

def isr_motorB(dummy):
    global B_count
    B_count += 1

def isr_speed_timer(dummy):
    global A_count, B_count, A_speed_count, B_speed_count
    A_speed_count = A_count
    B_speed_count = B_count
    A_count = 0
    B_count = 0

micropython.alloc_emergency_exception_buf(100)

from pyb import ExtInt
motorA_int = ExtInt('Y4', ExtInt.IRQ_RISING, Pin.PULL_NONE, isr_motorA)
motorB_int = ExtInt('Y6', ExtInt.IRQ_RISING, Pin.PULL_NONE, isr_motorB)

speed_timer = pyb.Timer(4, freq=10)
speed_timer.callback(isr_speed_timer)

# -----------------------------
# Parameters
# -----------------------------
MAX_ANGLE = 180
MAX_RPS = 4
DEAD_ZONE = 3

Kp = 12
Ki = 1.5
PWM_MAX = 90

# -----------------------------
# PI state
# -----------------------------
A_integral = 0
B_integral = 0
A_pwm = 0
B_pwm = 0

# -----------------------------
# helpers
# -----------------------------
def clamp(x, l, h):
    if x < l:
        return l
    if x > h:
        return h
    return x

def angle_to_target_rps(a):
    if abs(a) < DEAD_ZONE:
        return 0
    a = clamp(a, -MAX_ANGLE, MAX_ANGLE)
    return a * MAX_RPS / MAX_ANGLE

def pi_update(target, speed, integral, current_pwm, dt):
    error = target - speed

    integral += error * dt
    integral = clamp(integral, -15, 15)

    correction = Kp * error + Ki * integral

    new_pwm = current_pwm + correction
    new_pwm = clamp(new_pwm, 0, PWM_MAX)

    return new_pwm, integral, correction, error

# -----------------------------
# Start screen
# -----------------------------
oled_show_idle()

while not switch():
    pyb.delay(20)

while switch():
    pyb.delay(20)

oled_show_running()
pyb.delay(500)

# -----------------------------
# Main loop
# -----------------------------
tic = pyb.millis()

while True:

    toc = pyb.millis()
    dt = (toc - tic) * 0.001
    tic = toc
    if dt <= 0:
        dt = 0.001

    pitch = imu.pitch()
    target = angle_to_target_rps(pitch)

    spdA = A_speed_count / 39
    spdB = B_speed_count / 39

    direction = 0
    if target > 0:
        direction = 1
    elif target < 0:
        direction = -1

    target_mag = abs(target)

    correction_A = 0
    correction_B = 0

    new_pwm_A = A_pwm
    new_pwm_B = B_pwm

    if direction == 0:

        A_stop()
        B_stop()

        A_pwm = 0
        B_pwm = 0
        A_integral = 0
        B_integral = 0

    else:

        new_pwm_A, A_integral, correction_A, errA = pi_update(
            target_mag, abs(spdA), A_integral, A_pwm, dt)

        new_pwm_B, B_integral, correction_B, errB = pi_update(
            target_mag, abs(spdB), B_integral, B_pwm, dt)

        A_pwm = new_pwm_A
        B_pwm = new_pwm_B

        if direction > 0:
            A_forward(A_pwm)
            B_forward(B_pwm)
        else:
            A_back(A_pwm)
            B_back(B_pwm)

    # -----------------------------
    # OLED display
    # -----------------------------
    oled.clear()

    oled.draw_text(0, 0, "spdA:{:.2f}".format(spdA))
    oled.draw_text(0, 10, "spdB:{:.2f}".format(spdB))

    oled.draw_text(0, 25, "corA:{:.1f}".format(correction_A))
    oled.draw_text(0, 35, "corB:{:.1f}".format(correction_B))

    oled.draw_text(0, 50, "pA:{:.1f}".format(new_pwm_A))
    oled.draw_text(64, 50, "pB:{:.1f}".format(new_pwm_B))

    oled.display()

    pyb.delay(30)