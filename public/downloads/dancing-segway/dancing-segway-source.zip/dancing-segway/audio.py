"""
-------------------------------------------------------
Name: audio
Creator:  Peter Y K Cheung, Imperial College London
Date:   2 March 2022
Revision: 2.0
-------------------------------------------------------
Acquire real-time data from microphone at 8kHz sampling frequency
Find energy in 20msec window
-------------------------------------------------------
"""
from array import array
import micropython
micropython.alloc_emergency_exception_buf(100)

class MICROPHONE(object):
    def __init__(self, timer, mic, N):

        # initialise variables used for beat detection
        self.s_buf = array('h', 0 for i in range(N))    # reserve space for samples
        self.count = 0  # sample buffer index pointer
        self.E = 0
        self.sum = 0
        self.mic = mic
        self.N = N
        self.buffer_full = False

        # Specify timer 7 interrupt service routine
        timer.callback(self.isr_sampling)

    # Interrupt service routine to fill sample buffer s_buf
    def isr_sampling(self,dummy):  # timer interrupt at 8kHz
        MIC_OFFSET = 1523  # ADC reading of microphone for silence
        s = self.mic.read() - MIC_OFFSET  # read one sample and remove dc offset
        self.s_buf[self.count] = s
        self.count = self.count + 1  # increment sample count
        self.sum = self.sum + s * s
        if self.count == self.N:  # when reach N
            self.count = 0
            self.E = self.sum
            self.sum = 0
            self.buffer_full = True

    def inst_energy(self):
        return self.E
    
    def buffer_is_filled(self):
        return self.buffer_full
    
    def reset_buffer(self):
        self.buffer_full = False

    def data(self):
        return self.s_buf