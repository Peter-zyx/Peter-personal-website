import pyb
import micropython
from pyb import Pin, Timer, ExtInt
from oled_938 import OLED_938
from mpu6050 import MPU6050

micropython.alloc_emergency_exception_buf(100)

# -----------------------------
# Motor pins
# -----------------------------
A1 = Pin('X3', Pin.OUT_PP)
A2 = Pin('X4', Pin.OUT_PP)
PWMA = Pin('X1')

B1 = Pin('X7', Pin.OUT_PP)
B2 = Pin('X8', Pin.OUT_PP)
PWMB = Pin('X2')

# -----------------------------
# PWM setup
# -----------------------------
tim = Timer(2, freq=1000)
motorA = tim.channel(1, Timer.PWM, pin=PWMA)
motorB = tim.channel(2, Timer.PWM, pin=PWMB)

# -----------------------------
# OLED
# -----------------------------
i2c_oled = pyb.I2C(2, pyb.I2C.MASTER)
oled_addr = i2c_oled.scan()[0]

oled = OLED_938(
    pinout={"sda": "Y10", "scl": "Y9", "res": "Y8"},
    height=64,
    external_vcc=False,
    i2c_devid=oled_addr,
)

oled.poweron()
oled.init_display()

def oled_clear():
    try:
        oled.clear()
    except:
        try:
            oled.fill(0)
        except:
            pass

def oled_show_idle():
    oled_clear()
    oled.draw_text(0, 0, 'Challenge 3')
    oled.draw_text(0, 20, 'Tilt Motor Task')
    oled.draw_text(0, 40, 'Press USER to start')
    oled.display()

def oled_show_running():
    oled_clear()
    oled.draw_text(0, 0, 'Running...')
    oled.display()

def oled_show_error(msg):
    oled_clear()
    oled.draw_text(0, 0, 'Runtime error')
    oled.draw_text(0, 16, str(msg))
    oled.display()

# -----------------------------
# USER switch
# -----------------------------
switch = pyb.Switch()

# -----------------------------
# IMU
# -----------------------------
imu = MPU6050(1, False)

# -----------------------------
# Motor control
# -----------------------------
def A_forward(v):
    v = max(0, min(100, int(v)))
    A1.low()
    A2.high()
    motorA.pulse_width_percent(v)

def A_back(v):
    v = max(0, min(100, int(v)))
    A2.low()
    A1.high()
    motorA.pulse_width_percent(v)

def A_stop():
    A1.high()
    A2.high()
    motorA.pulse_width_percent(0)

def B_forward(v):
    v = max(0, min(100, int(v)))
    B2.low()
    B1.high()
    motorB.pulse_width_percent(v)

def B_back(v):
    v = max(0, min(100, int(v)))
    B1.low()
    B2.high()
    motorB.pulse_width_percent(v)

def B_stop():
    B1.high()
    B2.high()
    motorB.pulse_width_percent(0)

# -----------------------------
# Hall sensors
# -----------------------------
A_count = 0
B_count = 0
A_speed_count = 0
B_speed_count = 0

def isr_motorA(dummy):
    global A_count
    A_count += 1

def isr_motorB(dummy):
    global B_count
    B_count += 1

def isr_speed_timer(dummy):
    global A_count, B_count, A_speed_count, B_speed_count
    A_speed_count = A_count
    B_speed_count = B_count
    A_count = 0
    B_count = 0

motorA_int = ExtInt('Y4', ExtInt.IRQ_RISING, Pin.PULL_NONE, isr_motorA)
motorB_int = ExtInt('Y6', ExtInt.IRQ_RISING, Pin.PULL_NONE, isr_motorB)

speed_timer = pyb.Timer(4, freq=10)   # every 0.1 s
speed_timer.callback(isr_speed_timer)

# -----------------------------
# Parameters
# -----------------------------
MAX_ANGLE = 90
MAX_RPS = 4
DEAD_ZONE = 3

Kp = 12
Ki = 1.5
PWM_MAX = 90

# -----------------------------
# PI state
# -----------------------------
A_integral = 0
B_integral = 0
A_pwm = 0
B_pwm = 0

# -----------------------------
# Helpers
# -----------------------------
def clamp(x, l, h):
    if x < l:
        return l
    if x > h:
        return h
    return x

def angle_to_target_rps(a):
    if abs(a) < DEAD_ZONE:
        return 0
    a = clamp(a, -MAX_ANGLE, MAX_ANGLE)
    return a * MAX_RPS / MAX_ANGLE

def pi_update(target, speed, integral, current_pwm, dt):
    error = target - speed

    integral += error * dt
    integral = clamp(integral, -15, 15)

    correction = Kp * error + Ki * integral

    new_pwm = current_pwm + correction
    new_pwm = clamp(new_pwm, 0, PWM_MAX)

    return new_pwm, integral, correction, error

# -----------------------------
# Start in idle mode
# -----------------------------
oled_show_idle()
print('Idle mode: press USER to start')

while not switch():
    pyb.delay(20)

while switch():
    pyb.delay(20)

oled_show_running()
print('Program started')

# -----------------------------
# Main loop
# -----------------------------
tic = pyb.millis()
last_oled_ms = pyb.millis()

try:
    while True:
        toc = pyb.millis()
        dt = (toc - tic) * 0.001
        tic = toc
        if dt <= 0:
            dt = 0.001

        pitch = imu.pitch()
        target = angle_to_target_rps(pitch)

        spdA = A_speed_count / 39
        spdB = B_speed_count / 39

        direction = 0
        if target > 0:
            direction = 1
        elif target < 0:
            direction = -1

        target_mag = abs(target)

        correction_A = 0
        correction_B = 0

        new_pwm_A = A_pwm
        new_pwm_B = B_pwm

        if direction == 0:
            A_stop()
            B_stop()

            A_pwm = 0
            B_pwm = 0
            A_integral = 0
            B_integral = 0

        else:
            new_pwm_A, A_integral, correction_A, errA = pi_update(
                target_mag, abs(spdA), A_integral, A_pwm, dt
            )

            new_pwm_B, B_integral, correction_B, errB = pi_update(
                target_mag, abs(spdB), B_integral, B_pwm, dt
            )

            A_pwm = new_pwm_A
            B_pwm = new_pwm_B

            if direction > 0:
                A_forward(A_pwm)
                B_forward(B_pwm)
            else:
                A_back(A_pwm)
                B_back(B_pwm)

        # -----------------------------
        # OLED display (low refresh)
        # -----------------------------
        if pyb.elapsed_millis(last_oled_ms) >= 200:
            last_oled_ms = pyb.millis()

            oled_clear()
            oled.draw_text(0, 0, "spdA:{:.2f}".format(spdA))
            oled.draw_text(0, 10, "spdB:{:.2f}".format(spdB))
            oled.draw_text(0, 25, "corA:{:.1f}".format(correction_A))
            oled.draw_text(0, 35, "corB:{:.1f}".format(correction_B))
            oled.draw_text(0, 50, "pA:{:.1f}".format(new_pwm_A))
            oled.draw_text(64, 50, "pB:{:.1f}".format(new_pwm_B))
            oled.display()

        pyb.delay(30)

except Exception as e:
    print('Error:', e)
    oled_show_error(e)

finally:
    A_stop()
    B_stop()
    print('Motors stopped')