import pyb
import micropython
from pyb import Pin, Timer
from oled_938 import OLED_938
from audio import MICROPHONE
from array import array

# ----------------------------------------
# Motor pins
# ----------------------------------------
A1 = Pin('X3', Pin.OUT_PP)
A2 = Pin('X4', Pin.OUT_PP)
PWMA = Pin('X1')

B1 = Pin('X7', Pin.OUT_PP)
B2 = Pin('X8', Pin.OUT_PP)
PWMB = Pin('X2')

# ----------------------------------------
# PWM setup
# ----------------------------------------
tim = Timer(2, freq=1000)
motorA = tim.channel(1, Timer.PWM, pin=PWMA)
motorB = tim.channel(2, Timer.PWM, pin=PWMB)

# ----------------------------------------
# OLED setup
# ----------------------------------------
i2c = pyb.I2C(2, pyb.I2C.MASTER)
oled = OLED_938(
    pinout={"sda": "Y10", "scl": "Y9", "res": "Y8"},
    height=64,
    external_vcc=False,
    i2c_devid=i2c.scan()[0],
)
oled.poweron()
oled.init_display()
oled.clear()
oled.draw_text(0, 0, "Segway Dance")
oled.display()

# ----------------------------------------
# Audio / microphone setup
# ----------------------------------------
micropython.alloc_emergency_exception_buf(100)
audio = MICROPHONE(160)

# ----------------------------------------
# Motor control functions
# ----------------------------------------
def A_forward(value):
    A1.low()
    A2.high()
    motorA.pulse_width_percent(int(value))

def A_back(value):
    A2.low()
    A1.high()
    motorA.pulse_width_percent(int(value))

def A_stop():
    A1.high()
    A2.high()
    motorA.pulse_width_percent(0)

def B_forward(value):
    B2.low()
    B1.high()
    motorB.pulse_width_percent(int(value))

def B_back(value):
    B1.low()
    B2.high()
    motorB.pulse_width_percent(int(value))

def B_stop():
    B1.high()
    B2.high()
    motorB.pulse_width_percent(0)

# ----------------------------------------
# Basic motion functions
# ----------------------------------------
STEP_PWM = 40
TURN_PWM = 35

def move_forward():
    A_forward(STEP_PWM)
    B_forward(STEP_PWM)

def move_backward():
    A_back(STEP_PWM)
    B_back(STEP_PWM)

def turn_left():
    A_back(TURN_PWM)
    B_forward(TURN_PWM)

def turn_right():
    A_forward(TURN_PWM)
    B_back(TURN_PWM)

def stop_motion():
    A_stop()
    B_stop()

# ----------------------------------------
# Beat flash indicator
# ----------------------------------------
led = pyb.LED(4)

def flash():
    led.on()
    pyb.delay(20)
    led.off()

# ----------------------------------------
# Read dance file
# ----------------------------------------
def read_dance_file(filename='/sd/dance.txt'):
    try:
        f = open(filename, 'r')
        data = f.read()
        f.close()
        data = data.replace('\n', '').replace('\r', '').replace(' ', '')
        return data
    except:
        return "FFSSBBSSLRLRSS"

# ----------------------------------------
# Mount SD card
# ----------------------------------------
try:
    sd = pyb.SDCard()
    pyb.mount(sd, '/sd')
except:
    pass

dance_moves = read_dance_file()
move_index = 0
current_cmd = 'S'

# ----------------------------------------
# Command execution
# ----------------------------------------
def execute_command(cmd):
    if cmd == 'F':
        move_forward()
    elif cmd == 'B':
        move_backward()
    elif cmd == 'L':
        turn_left()
    elif cmd == 'R':
        turn_right()
    elif cmd == 'S':
        stop_motion()
    else:
        stop_motion()

# ----------------------------------------
# Beat detection parameters
# ----------------------------------------
M = 50                    # number of windows to average
BEAT_THRESHOLD = 2.8      # c threshold
MIN_BEAT_PERIOD = 200    # ms

# ----------------------------------------
# Circular buffer for energies
# ----------------------------------------
e_ptr = 0
e_buf = array('L', [0] * M)
sum_energy = 0

tic = pyb.millis()        # last beat time
beat_count = 0

# OLED refresh limiter
last_oled = pyb.millis()
OLED_PERIOD = 100

# ----------------------------------------
# Main loop
# ----------------------------------------
while True:

    if audio.buffer_is_filled():

        # 1) fetch energy for this 20 ms window
        E = audio.inst_energy()
        audio.reset_buffer()

        # 2) moving sum / average over last M windows
        sum_energy = sum_energy - e_buf[e_ptr] + E
        e_buf[e_ptr] = E
        e_ptr = (e_ptr + 1) % M
        average_energy = sum_energy / M

        # 3) compute c safely
        c = 0.0
        if average_energy > 0:
            c = E / average_energy

        # 4) beat decision with min beat period
        now = pyb.millis()
        if (now - tic) > MIN_BEAT_PERIOD:
            if c > BEAT_THRESHOLD:
                flash()
                tic = now
                beat_count += 1

                # ---- execute next dance move on each beat ----
                if len(dance_moves) > 0:
                    current_cmd = dance_moves[move_index]
                    move_index += 1
                    if move_index >= len(dance_moves):
                        move_index = 0

                    execute_command(current_cmd)

        # 5) OLED display
        if (now - last_oled) >= OLED_PERIOD:
            last_oled = now
            oled.clear()
            oled.draw_text(0, 0,  "Segway Dance")
            oled.draw_text(0, 12, "Cmd :{}".format(current_cmd))
            oled.draw_text(0, 22, "E   :{:10d}".format(int(E)))
            oled.draw_text(0, 32, "avg :{:10d}".format(int(average_energy)))
            oled.draw_text(0, 42, "c   :{:6.2f}".format(c))
            oled.draw_text(0, 52, "beats:{:6d}".format(beat_count))
            oled.display()