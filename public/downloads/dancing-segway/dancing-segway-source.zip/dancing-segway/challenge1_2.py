import pyb
from pyb import Pin, Timer, ADC
from audio import MICROPHONE
from neopixel import NeoPixel
from oled_938 import OLED_938
import micropython

micropython.alloc_emergency_exception_buf(100)

# OLED setup
i2c = pyb.I2C(2, pyb.I2C.MASTER)
scan = i2c.scan()
oled_addr = scan[0] if scan else 0x3C

oled = OLED_938(
    pinout={"sda": "Y10", "scl": "Y9", "res": "Y8"},
    height=64,
    external_vcc=False,
    i2c_devid=oled_addr,
)

oled.poweron()
oled.init_display()
oled.draw_text(0, 0, "Challenge 1")
oled.draw_text(0, 20, "Dancing LEDs")
oled.draw_text(0, 40, "Ready")
oled.display()

switch = pyb.Switch()
while not switch():
    pyb.delay(1)
while switch():
    pass

oled.draw_text(0, 40, "Running")
oled.display()

NUM_LEDS = 8
np = NeoPixel(Pin("Y12", Pin.OUT), NUM_LEDS)

def clear_leds():
    for i in range(NUM_LEDS):
        np[i] = (0, 0, 0)
    np.write()

def show_leds(n):
    for i in range(NUM_LEDS):
        if i < n:
            np[i] = (0, 0, 50)
        else:
            np[i] = (0, 0, 0)
    np.write()

clear_leds()

sample_timer = pyb.Timer(7, freq=8000)
mic = ADC(Pin("Y11"))
N = 160
audio = MICROPHONE(sample_timer, mic, N)

baseline = 0
alpha = 0.98

d0 = 0
d1 = 0
d2 = 0

PEAK_THRESHOLD = 10000
MIN_BEAT_PERIOD = 180
last_beat = pyb.millis()

while True:
    if audio.buffer_is_filled():
        E = audio.inst_energy()
        audio.reset_buffer()

        if baseline == 0:
            baseline = E
        else:
            baseline = alpha * baseline + (1 - alpha) * E

        diff = E - baseline
        now = pyb.millis()

        d0 = d1
        d1 = d2
        d2 = diff

        if d1 > PEAK_THRESHOLD and d1 > d0 and d1 > d2 and (now - last_beat) > MIN_BEAT_PERIOD:
            last_beat = now

            if d1 > 30000:
                level = 8
            elif d1 > 20000:
                level = 6
            elif d1 > 12000:
                level = 4
            else:
                level = 2

            show_leds(level)
            pyb.delay(50)
            clear_leds()