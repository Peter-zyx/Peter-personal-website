Dancing Segway — selected development archive

Original files from the supplied challenge directory; contents are unchanged.
These scripts target MicroPython on the Pyboard/PyBench teaching platform.

challenge_1.py / challenge1_2.py: audio-reactive LEDs and detector variants.
challenge_2.py: pitch/roll motor experiments.
challenge_3*.py: tilt targets with wheel-speed feedback, several iterations.
c4.py / challenge_4.py: beat-triggered movement sequences.
challenge_5.py: separate pitch PID balance controller.
dance.txt: FBFBLRLR sequence.
user.py: archived entry point selecting challenge_5.py.

Teaching support libraries retain their original author/copyright headers.
In particular audio.py and motor.py credit Peter Y K Cheung, Imperial College London.
The project builds on these libraries; their authorship is not claimed by Yuxuan Zhou.
Other unrelated lab exercises and the supplied bgs.wav music file are omitted.

This is a development snapshot, not a tested deployment package. The beat-driven
script and balance script are separate entry points. No integrated dancing/balance
controller is present here. The optional pitch_offset.txt is not in the archive;
challenge_5.py defaults to zero when it is missing. No board execution was performed
when preparing this portfolio. Keep each file's original attribution.
