from HackbotV2 import move, stop
import time

while True:
    move(50,50)
    time.sleep(1)
    stop()
    time.sleep(1)
    move(100,0)
    time.sleep(1)
    stop()
    time.sleep(1)
