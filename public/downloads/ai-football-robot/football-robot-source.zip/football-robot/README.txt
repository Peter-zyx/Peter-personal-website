AI Football Robot — source snapshot

Original files from iexplore, unchanged:
main.py — camera setup, detection interval and movement decisions.
HackbotV2.py — board pin mapping and differential motor driver.
Motor_TEST.py — isolated motor exercise.
training/dataset_capture_script.py — OpenMV dataset capture setup.
training/labels.txt — three labels in the local capture folder.

The imported ei_object_detection module and trained model are absent from the
supplied folder. This is a controller/capture archive, not a complete deployable
inference package. No hardware execution was performed for this portfolio.

The local training folder contains 358 JPEGs: 202 football, 72 goal, 84 robot.
The supplied Edge Impulse screenshot shows five object labels plus background;
this local capture subset is not treated as the full training export.

The author identifies the red robot and describes the match strategy as recognising
the goal and prioritising defence. The saved main.py contains mixed movement rules
and is presented as a development snapshot, not verified final match firmware.

The recorded project debrief describes two defenders and one attacker. Defenders
seek the friendly goal and occupy its sides; the exact threshold-based defender
implementation is not included in main.py. The recording reports reversed attacker
motor direction and difficulty seeing the goal from corners.
