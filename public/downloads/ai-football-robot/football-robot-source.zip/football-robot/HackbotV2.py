from machine import Pin
from pyb import Timer
from time import sleep


#Timer and Channel addresses for specific Nicla pins
"""
| PIN NAME | CHANNEL | TIMER | Digital |
----------------------------------------
| PB_3     | 2       | 2     |         |
| PA_10    | 3       | 1     | 2       |
| PA_9     | 2       | 1     | 1       |
| PB_8     | 1(3)    | 16(4) | 12      | --- Can choose either ch1 tim16 or ch3 tim4
| PB_9     | 1(4)    | 17(4) | 11      | --- Can choose either ch1 tim17 or ch4 tim4
| PE_12    | 3N      | 1     | 9       |
| PE_13    | 3       | 1     |         |
| PE_14    | 4       | 1     |         |
| PE_11    | 2       | 1     |         |
----------------------------------------

              -------------------
             |   |   |      0 0 0|   VIN
          A0 |0  |___|          0|   NC
          A1 |0                 0|   VOUT
        PE12 |0                 0|   GND
(PWMB)  PE13 |0                 0|   D3  (DO NOT USE)
(PWMA)  PE14 |0                 0|   D2  (BIN2)
 (AIN2) PE11 |0                 0|   D1  (BIN1)
 (AIN1)   A2 |0                 0|   PB8 (SCL)
(stnby)   D0 |0                 0|   PB9 (SDA)
              -------------------

A is LEFT
B is RIGHT

"""

leftneg = Pin("A2",Pin.OUT)
leftpos = Pin("PE11",Pin.OUT)
pwm = Pin("PE14",Pin.OUT)
rightpos = Pin("D2",Pin.OUT)
rightneg = Pin("D1",Pin.OUT)
pwmr = Pin("PE13",Pin.OUT)

stnd = Pin("D0",Pin.OUT)
stnd.high()
"""
pwm.high()
pwmr.high()
"""

tim1 = Timer(1,freq=1000)
ch1 = tim1.channel(4,Timer.PWM,pin=pwm)
ch2 = tim1.channel(3,Timer.PWM,pin=pwmr)

def pwm(power1,power2):
    ch1.pulse_width_percent(power1)
    ch2.pulse_width_percent(power2)

def move(left,right):
    lpower = left
    rpower = right
    if left < 0:
        lpower = lpower*-1
    if right < 0:
        rpower = rpower*-1
    pwm(lpower,rpower)

    if left < 0:
        leftpos.low()
        leftneg.high()
    if right < 0:
        rightpos.low()
        rightneg.high()
    if left >= 0:
        leftpos.high()
        leftneg.low()
    if right >= 0:
        rightpos.high()
        rightneg.low()

def stop():
    leftpos.low()
    rightpos.low()
    leftneg.low()
    rightneg.low()
