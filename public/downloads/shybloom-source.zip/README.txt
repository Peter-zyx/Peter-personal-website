ShyBloom — Group 40, Cici Song and Yuxuan Zhou
Original source snapshot supplied with the project archive.

ino.cpp: Bela Arduino/Wiring application logic.
render.cpp: Bela C++ runtime integration.
_main.pd: Pure Data template.

This archive is reference material, not a verified hardware release.
The supplied ino.cpp initializes position to 0.09, but its dark-state guard excludes 0.09. The reverse transition is similarly guarded. State transitions need review before hardware reuse. The potentiometer pin also differs between the portfolio drawing and this source. The website interaction illustrates the behaviour described in the portfolio; it is not an execution of this firmware.
