//opt/Bela/bela_flash_emmc.sh// Bela-Arduino template project
// Physical Computing (Gizmo) 2024
// Bela.io / Imperial College London

// ino.cpp: this file is for code in the Arduino (Wiring) language

#include <libraries/BelaArduino/Arduino.h>
#include <libraries/BelaArduino/PdArduino.h>
#include <libraries/Watcher/Watcher.h>

const unsigned int PIN_LDR = 0; 
const unsigned int PIN_LED = 1; 
const unsigned int PIN_BUTTON = 2;
const float threshold = 0.25;
const int PIN_SERVO = 0;
const int PIN_potentiometer = 2;
float currrentposition = 0;
bool breathingstatus = false;
float breathPhase = 0.0;
int breathDirection = 1;
const float breathStep = 0.02;
int initialButtonReading = HIGH;

// This function runs once at the beginning

void setup()
{
	pinMode(PIN_LED,OUTPUT);
	pinMode(PIN_LDR,OUTPUT);
	pinMode(PIN_SERVO,OUTPUT);
	pinMode(PIN_BUTTON,INPUT);
	currrentposition = 0.09;
	pwmWrite(PIN_SERVO,0.09,50);
}


// This function runs in a loop, forever
void loop()
{
	float raw = analogRead(PIN_LDR);  
	Serial.print("The LDR reading:");
	Serial.println(raw);
	float potentialreading = analogRead(PIN_potentiometer);
	Serial.print("The potentiometer reading:");
	Serial.println(potentialreading);
	if (raw >= threshold && currrentposition != 0.025){
		digitalWrite(PIN_LED,LOW);
		for (float d=currrentposition; d<=0.09; d+=0.001){
			pwmWrite(PIN_SERVO,d,50);
			delay(20);
		}
		currrentposition = 0.09;
	}
	if (raw < threshold && currrentposition != 0.09){
		int currentButtonReading = digitalRead(PIN_BUTTON);
		if (currentButtonReading != initialButtonReading) {
        	delay(10);
        	int checkState = digitalRead(PIN_BUTTON);
        	if (checkState == currentButtonReading) {
            	if (currentButtonReading == LOW) {  
                	breathingstatus = !breathingstatus; 
            	}
            initialButtonReading = currentButtonReading;
        	}
    	}
    	float duty = 0.0;
    	if (breathingstatus){
    		breathPhase += breathDirection*breathStep;
    		if (breathPhase >= 1){
    			breathPhase = 1;
    			breathDirection = -1;
    		} else if (breathPhase <= 0){
    			breathPhase = 0;
    			breathDirection = 1;
    		} 
    		duty = breathPhase * potentialreading;
    	} else{
    		duty = potentialreading;
    	}
    	pwmWrite(PIN_LED, duty, 1000);
		for (float d=currrentposition; d>=0.025; d-=0.001){
			pwmWrite(PIN_SERVO,d,50);
			delay(20);
		}
		currrentposition = 0.025;
		
	}
	
	delay(20); 
}
